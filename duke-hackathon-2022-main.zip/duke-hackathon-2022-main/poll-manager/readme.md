this is poll-manager
