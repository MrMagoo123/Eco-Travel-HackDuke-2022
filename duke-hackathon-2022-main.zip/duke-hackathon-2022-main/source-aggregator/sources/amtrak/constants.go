package amtrak

const (
	SensorDataRetries = 3
)
