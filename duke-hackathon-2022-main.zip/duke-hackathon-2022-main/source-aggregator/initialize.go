package main

import "github.com/maxwellmlin/duke-hackathon-2022/source-aggregator/pkg/funcs"

func initialize() {
	// initialize the logger
	funcs.InitiateLogger()

	// initialize the config
	// initialize the database
	// initialize the server
}
